package com.example.bluetooth.model.sensors

import android.content.Context
import android.util.Log
import com.example.bluetooth.model.data.SensorData
import com.example.bluetooth.model.data.SensorType
import com.polar.sdk.api.PolarBleApi
import com.polar.sdk.api.PolarBleApiDefaultImpl
import com.polar.sdk.api.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.onEach

class PolarSensorManager(private val context: Context) : SensorManager {

    companion object {
        private const val TAG = "PolarSensorManager"
    }

    private val api: PolarBleApi by lazy {
        PolarBleApiDefaultImpl.defaultImplementation(
            context,
            setOf(PolarBleApi.PolarBleSdkFeature.FEATURE_HR) // solo HR, acelerómetro y gyro no se declaran explícitamente
        )
    }

    private var connectedDeviceId: String? = null
    private var dataCallback: ((SensorData) -> Unit)? = null

    private val latestAcc = FloatArray(3)
    private val latestGyro = FloatArray(3)

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var sensorJob: Job? = null

    // ----------------------------
    // CONNECTION
    // ----------------------------
    override fun isAvailable(): Boolean = true

    override fun connect(onConnected: () -> Unit, onError: (String) -> Unit) {
        if (connectedDeviceId != null) {
            onConnected()
            return
        }

        scope.launch {
            try {
                val devices = api.searchForDevice()
                if (devices.isNotEmpty()) {
                    val device = devices.first()
                    api.connectToDevice(device.deviceId)
                    connectedDeviceId = device.deviceId
                    withContext(Dispatchers.Main) { onConnected() }
                } else {
                    withContext(Dispatchers.Main) { onError("No Polar devices found") }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Scan/connect error", e)
                withContext(Dispatchers.Main) { onError(e.message ?: "Unknown error") }
            }
        }
    }

    fun connectToDevice(deviceId: String, onConnected: () -> Unit, onError: (String) -> Unit) {
        scope.launch {
            try {
                api.connectToDevice(deviceId)
                connectedDeviceId = deviceId
                withContext(Dispatchers.Main) { onConnected() }
            } catch (e: Exception) {
                Log.e(TAG, "Connect error", e)
                withContext(Dispatchers.Main) { onError(e.message ?: "Connect failed") }
            }
        }
    }

    override fun disconnect() {
        connectedDeviceId?.let { id ->
            try {
                api.disconnectFromDevice(id)
            } catch (e: Exception) {
                Log.e(TAG, "Disconnect error", e)
            }
        }
        stopListening()
        connectedDeviceId = null
    }

    // ----------------------------
    // SENSOR STREAM
    // ----------------------------
    override fun startListening(callback: (SensorData) -> Unit) {
        val deviceId = connectedDeviceId ?: run {
            Log.e(TAG, "No device connected")
            return
        }

        dataCallback = callback

        sensorJob = scope.launch {
            startAccelerometer(deviceId)
            startGyroscope(deviceId)
        }
    }

    private suspend fun startAccelerometer(deviceId: String) {
        val settings = PolarSensorSetting(
            mapOf(
                PolarSensorSetting.SettingType.SAMPLE_RATE to 200,
                PolarSensorSetting.SettingType.RANGE to 8,
                PolarSensorSetting.SettingType.RESOLUTION to 16
            )
        )

        try {
            api.startAccStreaming(deviceId, settings)
                .onEach { accData: PolarAccelerometerData ->
                    accData.samples.forEach { sample ->
                        latestAcc[0] = sample.x.toFloat() / 1000f * 9.81f
                        latestAcc[1] = sample.y.toFloat() / 1000f * 9.81f
                        latestAcc[2] = sample.z.toFloat() / 1000f * 9.81f
                        emitSensorData(sample.timeStamp)
                    }
                }.collect()
        } catch (e: Exception) {
            Log.e(TAG, "Accelerometer streaming failed", e)
        }
    }

    private suspend fun startGyroscope(deviceId: String) {
        val settings = PolarSensorSetting(
            mapOf(
                PolarSensorSetting.SettingType.SAMPLE_RATE to 200,
                PolarSensorSetting.SettingType.RANGE to 2000,
                PolarSensorSetting.SettingType.RESOLUTION to 16
            )
        )

        try {
            api.startGyroStreaming(deviceId, settings)
                .onEach { gyroData: PolarGyroData ->
                    gyroData.samples.forEach { sample ->
                        latestGyro[0] = sample.x.toFloat()
                        latestGyro[1] = sample.y.toFloat()
                        latestGyro[2] = sample.z.toFloat()
                        emitSensorData(sample.timeStamp)
                    }
                }.collect()
        } catch (e: Exception) {
            Log.e(TAG, "Gyroscope streaming failed", e)
        }
    }

    override fun stopListening() {
        sensorJob?.cancel()
        sensorJob = null
        dataCallback = null
    }

    override fun getSensorType(): SensorType = SensorType.POLAR_VERITY_SENSE

    // ----------------------------
    // HELPERS
    // ----------------------------
    private fun emitSensorData(timestamp: Long) {
        dataCallback?.invoke(
            SensorData(
                timestamp = timestamp,
                sensorType = SensorType.POLAR_VERITY_SENSE,
                accelerometerX = latestAcc[0],
                accelerometerY = latestAcc[1],
                accelerometerZ = latestAcc[2],
                gyroscopeX = latestGyro[0],
                gyroscopeY = latestGyro[1],
                gyroscopeZ = latestGyro[2]
            )
        )
    }

    fun shutdown() {
        stopListening()
        connectedDeviceId?.let { api.disconnectFromDevice(it) }
        api.shutDown()
    }

    fun scanForDevices(
        onDeviceFound: (String, String) -> Unit,
        onError: (String) -> Unit
    ) {
        scope.launch {
            try {
                val devices = api.searchForDevice()
                devices.forEach { device ->
                    onDeviceFound(device.deviceId, device.name)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Scan error", e)
                withContext(Dispatchers.Main) { onError(e.message ?: "Scan failed") }
            }
        }
    }
}
